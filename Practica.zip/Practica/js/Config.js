const ROOT_NODE_ID="root"; //Id del nodo del que cuelgan todos los elementos

CONTAINER_INPUT_ID="chart-container";

const CHART_LOGO_CLASS="chart-logo";
const ADD_ICON_CLASS="add-icon";
const CHECK_ICON_CLASS="check-icon";
const UNCHECK_ICON_CLASS="uncheck-icon";
const REMOVE_ICON_CLASS="remove-icon";
const REFRESH_ICON_CLASS="refresh-icon";